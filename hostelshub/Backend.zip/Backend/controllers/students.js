export const registeredList = (req, res) => {
    res.send("Student list requested...");
}

export const feeDefaultersList = (req, res) => {
    res.send("Defaulters list requested...");
}



